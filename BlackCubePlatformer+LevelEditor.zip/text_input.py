import pygame
pygame.init()
type = 0
banned_keys = []
max_len = 20
screen_default_res = None
screen = None
font = None
keys = []
text_writed = ''
key_id = 0
sprites = [[], [], [], [], [], []]

class button():
    sprites = ()
    pos = (0, 0)
    rect = None
    touch = False
    old_touch = False
    def __init__(self, sprites, pos):
        self.sprites = sprites
        self.pos = pos
        self.rect = self.sprites[0].get_rect(topleft=self.pos)
    def render(self, screen):
        screen.blit(self.sprites[self.touch], self.pos)
    def touch_detect(self, fingers):
        self.old_touch = self.touch
        self.touch = False
        for finger, pos in fingers.items():
            if self.rect.collidepoint(pos):
                self.touch = True
    def touched(self):
        return self.old_touch and not self.touch

def set_buttons():
    global buttons
    buttons = {
        'Back': button(
            (
                sprites[0][0], 
                sprites[0][1]
            ), 
            (
                30 * (screen.get_width() / screen_default_res[0]), 
                60 * (screen.get_height() / screen_default_res[1])
            )
        ), 
        'Write': button(
            (
                sprites[2][0], 
                sprites[2][1]
            ), 
            (
                60 * (screen.get_width() / screen_default_res[0]), 
                60 * (screen.get_height() / screen_default_res[1])
            )
        ), 
        'Forward': button(
            (
                sprites[1][0], 
                sprites[1][1]
            ), 
            (
                90 * (screen.get_width() / screen_default_res[0]), 
                60 * (screen.get_height() / screen_default_res[1])
            )
        ), 
        'Space': button(
            (
                sprites[3][0], 
                sprites[3][1]
            ), 
            (
                120 * (screen.get_width() / screen_default_res[0]), 
                60 * (screen.get_height() / screen_default_res[1])
            )
        ), 
        'Clear': button(
            (
                sprites[4][0], 
                sprites[4][1]
            ), 
            (
                150 * (screen.get_width() / screen_default_res[0]), 
                60 * (screen.get_height() / screen_default_res[1])
            )
        ), 
        'Quit': button(
            (
                sprites[5][0], 
                sprites[5][1]
            ), 
            (
                90 * (screen.get_width() / screen_default_res[0]), 
                85 * (screen.get_height() / screen_default_res[1])
            )
        )
        
    }

def init(surf):
    global screen, screen_default_res, font, sprites
    screen = surf
    screen_default_res = (200, 100)
    font = pygame.font.Font('text_input_assets/T5.ttf', round(15 * (screen.get_width() / screen_default_res[0])))
    
    sprites = [
        [
            pygame.image.load('text_input_assets/images/b.png').convert_alpha(), 
            pygame.image.load('text_input_assets/images/ba.png').convert_alpha()
        ], 
        [
            pygame.image.load('text_input_assets/images/f.png').convert_alpha(), 
            pygame.image.load('text_input_assets/images/fa.png').convert_alpha()
        ], 
        [
            pygame.image.load('text_input_assets/images/w.png').convert_alpha(), 
            pygame.image.load('text_input_assets/images/wa.png').convert_alpha()
        ], 
        [
            pygame.image.load('text_input_assets/images/s.png').convert_alpha(), 
            pygame.image.load('text_input_assets/images/sa.png').convert_alpha()
        ], 
        [
            pygame.image.load('text_input_assets/images/c.png').convert_alpha(), 
            pygame.image.load('text_input_assets/images/ca.png').convert_alpha()
        ], 
        [
            pygame.image.load('text_input_assets/images/q.png').convert_alpha(), 
            pygame.image.load('text_input_assets/images/qa.png').convert_alpha()
        ]
    ]
    
    for id1, list in enumerate(sprites):
        for id2, item in enumerate(list):
            sprites[id1][id2] = pygame.transform.scale(
                item, 
                ((item.get_width() * (screen.get_width() / screen_default_res[0])), (item.get_height() * (screen.get_height() / screen_default_res[1])))
            )
    set_buttons()
            

def setup():
    global keys, buttons, type, max_len
    keys.clear()
    if type == 0:
        symbols = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789+-×÷#:_.,!?'
    elif type == 1:
        symbols = '0123456789+-×÷.'
    for symbol in symbols:
        if not symbol in banned_keys:
            keys.append(symbol)
    max_len = min(max(max_len, 0), 20)




def show_menu():
    global screen, buttons, text_writed, font, key_id, keys
    text_writed = ''
    text_writed_label = None
    key_id = 0
    key_selected_label = font.render(keys[key_id], False, (255, 255, 255))
    key_selected_rect = pygame.surface.Surface((18 * (screen.get_width() / screen_default_res[0]), 20 * (screen.get_height() / screen_default_res[1])))
    key_selected_rect.set_alpha(255 / 100 * 75)
    key_selected_rect = key_selected_rect.convert_alpha()
    fingers = {}
    running = True
    while running:
        key_selected_label = font.render(keys[key_id], False, (255, 255, 255))
        
        text_writed_label = font.render(text_writed, False, (0, 0, 0))
        screen.fill((255, 255, 255))
        for button in buttons:
            buttons[button].touch_detect(fingers)
            if buttons[button].touched():
                if button == 'Write':
                    text_writed += keys[key_id]
                elif button == 'Clear':
                    text_writed = text_writed[:-1]
                elif button == 'Space':
                    text_writed += ' '
                elif button == 'Back':
                    if key_id != 0:
                        key_id -= 1
                    else:
                        key_id = len(keys) - 1
                elif button == 'Forward':
                    if key_id != len(keys) - 1:
                        key_id += 1
                    else:
                        key_id = 0
                elif button == 'Quit':
                    running = False
            if len(text_writed) > max_len:
                text_writed = text_writed[:max_len - len(text_writed)]
            buttons[button].render(screen)
            
        screen.blit(text_writed_label, (screen.get_width() / 2 - text_writed_label.get_width() / 2, 10 * (screen.get_height() / screen_default_res[1])))
        screen.blit(key_selected_rect, (screen.get_width() / 2 - key_selected_rect.get_width() / 2, 30 * (screen.get_height() / screen_default_res[1])))
        screen.blit(key_selected_label, (screen.get_width() / 2 - key_selected_label.get_width() / 2, 40 * (screen.get_height() / screen_default_res[1]) - key_selected_label.get_height() / 2))
        pygame.display.update()
        try:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    pygame.quit()
                    quit()
                    break
                if event.type == pygame.FINGERDOWN:
                    fingers[event.finger_id] = (event.x * screen.get_width(), event.y * screen.get_height())
                if event.type == pygame.FINGERUP:
                    fingers.pop(event.finger_id)
        except Exception as e:
            print(e)