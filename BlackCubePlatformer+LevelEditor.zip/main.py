import pygame
import text_input
pygame.init()
screen_w = 200
screen_h = 100
screen = pygame.display.set_mode((screen_w, screen_h), pygame.SCALED | pygame.FULLSCREEN)
pygame.display.set_caption('BCP+ Level Editor')
font = pygame.font.Font('fonts/Tiny5.ttf', 15)
text_input.init(screen)

# game settings
fps = 30
clock = pygame.time.Clock()
fingers = {}
screen_fingers_touch = []

# textures
textures = {
    'blocks': [
        pygame.image.load('images/blocks/block1.png').convert_alpha(), 
        pygame.image.load('images/blocks/block2.png').convert_alpha(), 
        pygame.image.load('images/blocks/block1md.png').convert_alpha(), 
        pygame.image.load('images/blocks/block1mv.png').convert_alpha(), 
        pygame.image.load('images/blocks/block2md.png').convert_alpha(), 
        pygame.image.load('images/blocks/block2mv.png').convert_alpha(), 
        pygame.image.load('images/blocks/block1f.png').convert_alpha(), 
        pygame.image.load('images/blocks/block2f.png').convert_alpha(), 
        pygame.image.load('images/blocks/blockc.png').convert_alpha()
    ], 
    'items': [
        pygame.image.load('images/items/coin.png').convert_alpha(), 
        pygame.image.load('images/items/flag.png').convert_alpha(), 
        pygame.image.load('images/items/bad coin.png').convert_alpha()
    ], 
    'enemy': [
        pygame.image.load('images/enemy/e1.png').convert_alpha(), 
        pygame.image.load('images/enemy/e2.png').convert_alpha(), 
        pygame.image.load('images/enemy/ed.png').convert_alpha()
    ], 
    'player': [
        pygame.image.load('images/player/p1.png').convert_alpha(), 
        pygame.image.load('images/player/p2.png').convert_alpha(), 
        pygame.image.load('images/player/pd.png').convert_alpha()
    ]
}

# ui +{
ui = {
    'cam_buttons': [
        pygame.image.load('images/ui/b1.png').convert_alpha(), 
        pygame.image.load('images/ui/b1p.png').convert_alpha(), 
        pygame.image.load('images/ui/b2.png').convert_alpha(), 
        pygame.image.load('images/ui/b2p.png').convert_alpha(), 
        pygame.image.load('images/ui/b3.png').convert_alpha(), 
        pygame.image.load('images/ui/b3p.png').convert_alpha(), 
        pygame.image.load('images/ui/b4.png').convert_alpha(), 
        pygame.image.load('images/ui/b4p.png').convert_alpha()
    ], 
    'save': [
        pygame.image.load('images/ui/save.png').convert_alpha(), 
        pygame.image.load('images/ui/save_p.png').convert_alpha()
    ], 
    'load': [
        pygame.image.load('images/ui/load.png').convert_alpha(), 
        pygame.image.load('images/ui/load_p.png').convert_alpha()
    ], 
    'other': [
        pygame.image.load('images/ui/block_s.png').convert_alpha(), 
        pygame.image.load('images/ui/eraser.png').convert_alpha(), 
        pygame.image.load('images/ui/block_s_sp.png').convert_alpha()
    ]
}

class button_v1():
    pos = ()
    sprites = ()
    pressed = False
    old_pressed = pressed
    rect = None
    def __init__(self, pos, sprites):
        self.pos = pos
        self.sprites = sprites
        self.rect = self.sprites[0].get_rect(topleft=self.pos)
    def render(self, surf):
        surf.blit(self.sprites[self.pressed], self.pos)
    def touch(self, fingers):
        global screen_fingers_touch
        self.old_pressed = self.pressed
        self.pressed = False
        for finger, pos in fingers.items():
            if self.rect.collidepoint(pos):
                self.pressed = True
    def touched(self):
        return self.old_pressed and not self.pressed

class button_v2():
    pos = ()
    sprites = ()
    pressed = False
    rect = None
    def __init__(self, pos, sprites):
        self.pos = pos
        self.sprites = sprites
        self.rect = self.sprites[0].get_rect(topleft=self.pos)
    def render(self, surf):
        surf.blit(self.sprites[self.pressed], self.pos)
    def touch(self, fingers):
        global screen_fingers_touch
        self.pressed = False
        for finger, pos in fingers.items():
            if self.rect.collidepoint(pos):
                self.pressed = True
    def touching(self):
        return self.pressed

class picture():
    pos = ()
    sprite = None
    rect = None
    def __init__(self, pos, sprite):
        self.pos = pos
        self.sprite = sprite
        self.rect = self.sprite.get_rect(topleft=self.pos)
    def render(self, surf):
        surf.blit(self.sprite, self.pos)

class text_button():
    pos = ()
    object = None
    text = 'text'
    font = None
    colors = ((255, 255, 255), (200, 200, 200))
    pressed = False
    old_pressed = False
    rect = None
    def update_object(self):
        self.object = self.font.render(self.text, False, self.colors[self.pressed])
        self.rect = self.object.get_rect(topleft=self.pos)
    def __init__(self, pos, text, font):
        self.pos = pos
        self.text = text
        self.font = font
        self.update_object()
    def render(self, surf):
        self.update_object()
        surf.blit(self.object, self.pos)
    def touch(self, fingers):
        self.update_object()
        self.old_pressed = self.pressed
        self.pressed = False
        for finger, pos in fingers.items():
            if self.rect.collidepoint(pos):
                self.pressed = True
    def touched(self):
        return self.old_pressed and not self.pressed

save_button = button_v1((158, 2), (ui['save'][0], ui['save'][1]))
load_button = button_v1((158, 24), (ui['load'][0], ui['load'][1]))
cam_buttons = [
    button_v2((0 + 2, 70 - 2), (ui['cam_buttons'][2], ui['cam_buttons'][3])), 
    button_v2((40 + 2, 70 - 2), (ui['cam_buttons'][0], ui['cam_buttons'][1])), 
    button_v2((20 + 2, 60 - 2), (ui['cam_buttons'][4], ui['cam_buttons'][5])), 
    button_v2((20 + 2, 80 - 2), (ui['cam_buttons'][6], ui['cam_buttons'][7]))
]
block_s_button = button_v1((2, 2), (ui['other'][0], ui['other'][0]))
block_s_list = [
    textures['blocks'][0], 
    textures['blocks'][1], 
    textures['blocks'][4], 
    textures['blocks'][5], 
    textures['blocks'][6], 
    textures['blocks'][7], 
    textures['blocks'][8], 
    textures['items'][0], 
    textures['items'][2], 
    textures['items'][1], 
    font.render('t', False, (255, 255, 255)), 
    ui['other'][1]
]
block_s_sdv = [
    [], 
    [], 
    [0, 0], 
    [0, 0], 
    [0], 
    [0], 
    [0], 
    [], 
    [], 
    [], 
    ['text'], 
    []
]
block_s_fdv = [
    [0, 0, 4, 98], 
    [0, 1, 4, 98], 
    [0, 5, 4, 98, 0, 4, 4, 0], 
    [0, 5, 4, 98, 1, 98, 98, 0], 
    [0, 4, 4, 98, 0, 0], 
    [0, 3, 4, 98, 0, 0],
    [0, 2, 4, 98, 0, 0], 
    [0, 6, 4, 98], 
    [0, 7, 4, 98], 
    [0, 8, 4, 98], 
    [0, 9, 4, 98, 'text'], 
    []
]
block_s_id = 0
block_s_sp_picture = picture((24, 2), ui['other'][2])
block_s_si = [
    [], 
    [], 
    [
        text_button((block_s_sp_picture.pos[0] + 4, 2), 'r/l:0', font), 
        text_button((block_s_sp_picture.pos[0] + 40, 2), 'blocks:0', font)
    ], 
    [
        text_button((block_s_sp_picture.pos[0] + 4, 2), 'u/d:0', font), 
        text_button((block_s_sp_picture.pos[0] + 44, 2), 'blocks:0', font)
    ], 
    [
        text_button((block_s_sp_picture.pos[0] + 4, 2), 'first state:0', font)
    ], 
    [
        text_button((block_s_sp_picture.pos[0] + 4, 2), 'first state:0', font)
    ], 
    [
        text_button((block_s_sp_picture.pos[0] + 4, 2), 'first state:0', font)
    ], 
    [], 
    [], 
    [], 
    [
        text_button((block_s_sp_picture.pos[0] + 4, 2), 'text', font)
    ], 
    []
]
block_p_fv = None
block_p_sfv = None
block_p_sv = None
block_p_fv = block_s_fdv[block_s_id]
block_p_sv = block_s_sdv[block_s_id]


def place_block(id, pos):
    global block_p_fv, block_p_sfv, loaded_level
    # setting up file value
    if id == 0 or id == 1 or id == 7 or id == 8 or id == 9:
        block_p_fv[2], block_p_fv[3] = pos
    elif id == 2:
        block_p_fv[2], block_p_fv[3] = pos
        if block_p_sv[0] == 0:
            block_p_fv[5] = block_p_fv[2]
            block_p_fv[6] = block_p_fv[2] + block_p_sv[1] * 16
        elif block_p_sv[0] == 1:
            block_p_fv[6] = block_p_fv[2]
            block_p_fv[5] = block_p_fv[2] - block_p_sv[1] * 16
        block_p_fv[7] = block_p_sv[0]
    elif id == 3:
        block_p_fv[2], block_p_fv[3] = pos
        if block_p_sv[0] == 0:
            block_p_fv[5] = block_p_fv[3]
            block_p_fv[6] = block_p_fv[3] - (block_p_sv[1] * 16)
        elif block_p_sv[0] == 1:
            block_p_fv[6] = block_p_fv[3]
            block_p_fv[5] = block_p_fv[3] + (block_p_sv[1] * 16)
        block_p_fv[7] = block_p_sv[0]
    elif id == 4 or id == 5 or id == 6 or id == 10:
        block_p_fv[2], block_p_fv[3] = pos
        block_p_fv[4] = block_p_sv[0]
    # setting up str file value
    if id != 10:
        block_p_sfv = str(block_p_fv)
        block_p_sfv = block_p_sfv[1:-1]
    else:
        block_p_sfv = str([block_p_fv[0], block_p_fv[1], block_p_fv[2], block_p_fv[3]])
        block_p_sfv = block_p_sfv[1:-1]
        block_p_sfv += ', ' + block_p_fv[4]
    # adding it to the level
    loaded_level.append(block_p_sfv)
# }+

# screen touch detection
def screen_fingers_update():
    global screen_fingers_touch, fingers
    screen_fingers_touch.clear()
    for finger, pos in fingers.items():
        if not save_button.rect.collidepoint(pos) and not load_button.rect.collidepoint(pos) and  not cam_buttons[0].rect.collidepoint(pos) and not cam_buttons[1].rect.collidepoint(pos) and not cam_buttons[2].rect.collidepoint(pos) and not cam_buttons[3].rect.collidepoint(pos) and not block_s_button.rect.collidepoint(pos) and not block_s_sp_picture.rect.collidepoint(pos):
            screen_fingers_touch.append(finger)

# level
loaded_level = []
level_filename = '0.txt'
str_level = ''
object_splited = None
object_sprite = None
# save and load
def load_level(filename):
    try:
        with open('levels/' + filename, 'r') as file_level:
            return file_level.read().split('\n')
    except FileNotFoundError:
        return []
def save_level(filename, level):
    global str_level
    str_level = ''
    for idx, el in enumerate(loaded_level):
        if idx + 1 < len(loaded_level):
            str_level += el + '\n'
        else:
            str_level += el
    with open('levels/' + filename, 'w') as file_level:
        file_level.write(str_level)

# player settings
player_dir = 0
player_image = 0
player_pos = (screen_w / 2 - textures['player'][player_image].get_width() / 2, screen_h / 2 - textures['player'][0].get_height() / 2)

# cam vars
cam_x = 0
cam_y = 0

# game loop
run = True
while run:
    screen_fingers_touch.clear()
    
    # fps
    clock.tick(fps)
    
    
    
    # ui check touch
    save_button.touch(fingers)
    load_button.touch(fingers)
    if save_button.touched():
        save_level(level_filename, loaded_level)
    if load_button.touched():
        loaded_level = load_level(level_filename)
    cam_buttons[0].touch(fingers)
    cam_buttons[1].touch(fingers)
    cam_buttons[2].touch(fingers)
    cam_buttons[3].touch(fingers)
    block_s_button.touch(fingers)
    if block_s_button.touched():
        if block_s_id + 1 < len(block_s_list):
            block_s_id += 1
        else:
            block_s_id = 0
        block_p_fv = block_s_fdv[block_s_id]
        block_p_sv = block_s_sdv[block_s_id]
    for id, inp in enumerate(block_s_si[block_s_id]):
        inp.touch(fingers)
        if inp.touched():
            if block_s_id in [2, 3]:
                if id == 0:
                    text_input.type = 1
                    text_input.max_len = 1
                    text_input.banned_keys = [
                        '2', 
                        '3', 
                        '4', 
                        '5', 
                        '6', 
                        '7', 
                        '8', 
                        '9', 
                        '+', 
                        '-', 
                        '×', 
                        '÷', 
                        '.'
                    ]
                elif id == 1:
                    text_input.type = 1
                    text_input.max_len = 2
                    text_input.banned_keys = [
                        '+', 
                        '-', 
                        '×', 
                        '÷', 
                        '.'
                    ]
            elif block_s_id in [4, 5, 6]:
                text_input.type = 1
                text_input.max_len = 1
                text_input.banned_keys = [
                    '2', 
                    '3', 
                    '4', 
                    '5', 
                    '6', 
                    '7', 
                    '8', 
                    '9', 
                    '+', 
                    '-', 
                    '×', 
                    '÷', 
                    '.'
                ]
            elif block_s_id == 10:
                text_input.type = 0
                text_input.max_len = 20
                text_input.banned_keys = [',']
            text_input.setup()
            text_input.show_menu()
            
            if block_s_id in [2, 3]:
                if text_input.text_writed != '':
                    block_p_sv[id] = int(text_input.text_writed)
                else:
                    block_p_sv[id] = 0
            elif block_s_id in [4, 5, 6]:
                if text_input.text_writed != '':
                    block_p_sv[0] = int(text_input.text_writed)
                else:
                    block_p_sv[0] = 0
            elif block_s_id == 10:
                block_p_sv[0] = text_input.text_writed
            break
    
    
    for id, inp in enumerate(block_s_si[block_s_id]):
        if block_s_id in [2, 3]:
            if id == 0:
                if block_s_id == 2:
                    inp.text = 'r/l:' + str(block_p_sv[0])
                elif block_s_id == 3:
                    inp.text = 'u/d:' + str(block_p_sv[0])
            elif id == 1:
                inp.text = 'blocks:' + str(block_p_sv[1])
        elif block_s_id in [4, 5, 6]:
            inp.text = 'first state:' + str(block_p_sv[0])
        inp.update_object()
    
    # screen touch check
    screen_fingers_update()
    
    # placing blocks
    if block_s_id != 11:
        place = True
        for finger in screen_fingers_touch:
            for element in loaded_level:
                element_splited = element.split(', ')
                if len(element_splited) > 3:
                    if int(element_splited[2]) == round((fingers[finger][0] - 8 + cam_x) / 16) * 16 + 4 and int(element_splited[3]) == round((fingers[finger][1] - 8 + cam_y) / 16) * 16 + 2:
                        place = False
            if place:
                place_block(block_s_id, (round((fingers[finger][0] - 8 + cam_x) / 16) * 16 + 4, round((fingers[finger][1] - 8 + cam_y) / 16) * 16 + 2))
        del place
    else:
        for finger in screen_fingers_touch:
            for element in loaded_level:
                element_splited = element.split(', ')
                if len(element_splited) > 3:
                    if int(element_splited[2]) == round((fingers[finger][0] - 8 + cam_x) / 16) * 16 + 4 and int(element_splited[3]) == round((fingers[finger][1] - 8 + cam_y) / 16) * 16 + 2:
                        loaded_level.remove(element)
    
    
    cam_x += (cam_buttons[1].touching() - cam_buttons[0].touching()) * 2
    cam_y += (cam_buttons[3].touching() - cam_buttons[2].touching()) * 2
    
    # screen fill
    screen.fill((255, 255, 255))
    
    # level render ={
    for object in loaded_level:
        object_splited = object.split(', ')
        if object_splited[0] == '0':
            if int(object_splited[1]) == 0:
                object_sprite = textures['blocks'][0]
                if int(object_splited[2]) - cam_x > 0 - object_sprite.get_width() and int(object_splited[2]) - cam_x < screen_w and int(object_splited[3]) - cam_y > 0 - object_sprite.get_height() and int(object_splited[3]) - cam_y < screen_h:
                    screen.blit(object_sprite, (int(object_splited[2]) - cam_x, int(object_splited[3]) - cam_y))
            elif int(object_splited[1]) == 1:
                object_sprite = textures['blocks'][1]
                if int(object_splited[2]) - cam_x > 0 - object_sprite.get_width() and int(object_splited[2]) - cam_x < screen_w and int(object_splited[3]) - cam_y > 0 - object_sprite.get_height() and int(object_splited[3]) - cam_y < screen_h:
                    screen.blit(object_sprite, (int(object_splited[2]) - cam_x, int(object_splited[3]) - cam_y))
            elif int(object_splited[1]) == 2:
                object_sprite = textures['blocks'][8]
                if int(object_splited[2]) - cam_x > 0 - object_sprite.get_width() and int(object_splited[2]) - cam_x < screen_w and int(object_splited[3]) - cam_y > 0 - object_sprite.get_height() and int(object_splited[3]) - cam_y < screen_h:
                    screen.blit(object_sprite, (int(object_splited[2]) - cam_x, int(object_splited[3]) - cam_y))
            elif int(object_splited[1]) == 3:
                object_sprite = textures['blocks'][7]
                if int(object_splited[2]) - cam_x > 0 - object_sprite.get_width() and int(object_splited[2]) - cam_x < screen_w and int(object_splited[3]) - cam_y > 0 - object_sprite.get_height() and int(object_splited[3]) - cam_y < screen_h:
                    screen.blit(object_sprite, (int(object_splited[2]) - cam_x, int(object_splited[3]) - cam_y))
            elif int(object_splited[1]) == 4:
                object_sprite = textures['blocks'][6]
                if int(object_splited[2]) - cam_x > 0 - object_sprite.get_width() and int(object_splited[2]) - cam_x < screen_w and int(object_splited[3]) - cam_y > 0 - object_sprite.get_height() and int(object_splited[3]) - cam_y < screen_h:
                    screen.blit(object_sprite, (int(object_splited[2]) - cam_x, int(object_splited[3]) - cam_y))
            elif int(object_splited[1]) == 5:
                object_sprite = textures['blocks'][4] if int(object_splited[4]) == 0 else textures['blocks'][5]
                if int(object_splited[2]) - cam_x > 0 - object_sprite.get_width() and int(object_splited[2]) - cam_x < screen_w and int(object_splited[3]) - cam_y > 0 - object_sprite.get_height() and int(object_splited[3]) - cam_y < screen_h:
                    screen.blit(object_sprite, (int(object_splited[2]) - cam_x, int(object_splited[3]) - cam_y))
            elif int(object_splited[1]) == 6:
                object_sprite = textures['items'][0]
                if int(object_splited[2]) - cam_x > 0 - object_sprite.get_width() and int(object_splited[2]) - cam_x < screen_w and int(object_splited[3]) - cam_y > 0 - object_sprite.get_height() and int(object_splited[3]) - cam_y < screen_h:
                    screen.blit(object_sprite, (int(object_splited[2]) + 4 - cam_x, int(object_splited[3]) + 4 - cam_y))
            elif int(object_splited[1]) == 7:
                object_sprite = textures['items'][2]
                if int(object_splited[2]) - cam_x > 0 - object_sprite.get_width() and int(object_splited[2]) - cam_x < screen_w and int(object_splited[3]) - cam_y > 0 - object_sprite.get_height() and int(object_splited[3]) - cam_y < screen_h:
                    screen.blit(object_sprite, (int(object_splited[2]) + 4 - cam_x, int(object_splited[3]) + 4 - cam_y))
            elif int(object_splited[1]) == 8:
                object_sprite = textures['items'][1]
                if int(object_splited[2]) - cam_x > 0 - object_sprite.get_width() and int(object_splited[2]) - cam_x < screen_w and int(object_splited[3]) - cam_y > 0 - object_sprite.get_height() and int(object_splited[3]) - cam_y < screen_h:
                    screen.blit(object_sprite, (int(object_splited[2]) + 4 - cam_x, int(object_splited[3]) - cam_y))
            elif int(object_splited[1]) == 9:
                object_sprite = font.render(object_splited[4], False, (0, 0, 0))
                if int(object_splited[2]) - cam_x > 0 - object_sprite.get_width() and int(object_splited[2]) - cam_x < screen_w + object_sprite.get_width() and int(object_splited[3]) - cam_y > 0 - object_sprite.get_height() and int(object_splited[3]) - cam_y < screen_h:
                    screen.blit(object_sprite, (int(object_splited[2]) - object_sprite.get_width() / 2 - cam_x, int(object_splited[3]) - cam_y))
    # }=
    
    # player render
    if player_pos[0] - cam_x > 0 - textures['player'][player_image].get_width() and player_pos[0] - cam_x < screen_w and player_pos[1] - cam_y > 0 - textures['player'][player_image].get_height() and player_pos[1] - cam_y < screen_h:
        screen.blit(textures['player'][player_image], (player_pos[0] - cam_x, player_pos[1] - cam_y))
    
    # ui render
    save_button.render(screen)
    load_button.render(screen)
    cam_buttons[0].render(screen)
    cam_buttons[1].render(screen)
    cam_buttons[2].render(screen)
    cam_buttons[3].render(screen)
    block_s_button.render(screen)
    screen.blit(block_s_list[block_s_id], (block_s_button.pos[0] + 2 + (16 - block_s_list[block_s_id].get_width()) / 2, block_s_button.pos[1] + 2 + (16 - block_s_list[block_s_id].get_height()) / 2))
    block_s_sp_picture.render(screen)
    for inp in block_s_si[block_s_id]:
        inp.render(screen)
    
    # neutral code
    pygame.display.update()
    try:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                break
            if event.type == pygame.FINGERDOWN or event.type == pygame.FINGERMOTION:
                fingers[event.finger_id] = (event.x * screen_w, event.y * screen_h)
            if event.type == pygame.FINGERUP:
                fingers.pop(event.finger_id)
    except Exception as e:
        print(e)
pygame.quit()