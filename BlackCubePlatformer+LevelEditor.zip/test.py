import pygame
import text_input
pygame.init()
screen = pygame.display.set_mode((200, 100), pygame.SCALED | pygame.FULLSCREEN)
text_input.init(screen)

fingers = {}

class button():
    sprites = ()
    pos = ()
    rect = None
    pressed = False
    old_pressed = False
    def __init__(self, sprites, pos):
        self.sprites = sprites
        self.pos = pos
        self.rect = self.sprites[0].get_rect(topleft=self.pos)
    def render(self, surf):
        surf.blit(self.sprites[self.pressed], self.pos)
    def touch_detect(self, fingers):
        self.old_pressed = self.pressed
        self.pressed = False
        for id, pos in fingers.items():
            if self.rect.collidepoint(pos):
                self.pressed = True
    def touched(self):
        return self.old_pressed and not self.pressed

class button_with_text(button):
    text = None
    text_pos = (0, 0)
    def __init__(self, sprites, pos, text, font, color):
        super(button_with_text, self).__init__(sprites, pos)
        self.change_text(text, font, color)
    def render(self, surf):
        super(button_with_text, self).render(surf)
        surf.blit(self.text, (self.text_pos[0] + self.pos[0], self.text_pos[1] + self.pos[1]))

    def change_text(self, text, font, color):
        self.text = font.render(text, False, color)
        self.text_pos = (self.sprites[0].get_width() / 2 - self.text.get_width() / 2, self.sprites[0].get_height() / 2 - self.text.get_height() / 2)
    
text_button = button_with_text(
    (
        pygame.surface.Surface((100, 20)), 
        pygame.surface.Surface((100, 20)), 
    ), 
    (
        50, 
        40
    ), 
    '', 
    pygame.font.Font('fonts/Tiny5.ttf', 15), 
    (255, 255, 255)
)
text_button.sprites[1].fill((50, 50, 50))



run = True
while run:
    screen.fill((255, 255, 255))
    text_button.touch_detect(fingers)
    text_button.render(screen)
    if text_button.touched():
        text_input.type = 0
        text_input.max_len = 10
        text_input.setup()
        text_input.show_menu()
        text_button.change_text(text_input.text_writed, pygame.font.Font('fonts/Tiny5.ttf', 15), (255, 255, 255))
    pygame.display.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            break
        if event.type == pygame.FINGERDOWN:
            fingers[event.finger_id] = (event.x * screen.get_width(), event.y * screen.get_height())
        if event.type == pygame.FINGERUP:
            fingers.pop(event.finger_id)
pygame.quit()
quit()