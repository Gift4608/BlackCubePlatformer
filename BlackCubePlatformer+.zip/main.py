import time
import pygame
pygame.init()


# settings
screen_w = 200
screen_h = 100
screen = pygame.display.set_mode((screen_w, screen_h), pygame.SCALED | pygame.FULLSCREEN)
pygame.display.set_caption('Black Cube Platformer +')
font = pygame.font.Font('fonts/tiny5.ttf', 15)

# game settings
clock = pygame.time.Clock()
fps = 30
fingers = {}
events = []

# levels settings
level_name = '0'
level_file_name = level_name + '.txt'
levels_count = 15
loaded_level = []
level_hitboxes = [
    [], 
    [], 
    [], 
    []
]

# blocks sprites
blocks = [
    pygame.image.load('images/blocks/block1.png').convert_alpha(), 
    pygame.image.load('images/blocks/block2.png').convert_alpha(), 
    pygame.image.load('images/blocks/block1m.png').convert_alpha(), 
    pygame.image.load('images/blocks/block2m.png').convert_alpha()
]

# items sprites
items = [
    pygame.image.load('images/items/coin.png').convert_alpha(), 
    pygame.image.load('images/items/flag.png').convert_alpha(), 
    pygame.image.load('images/items/bad coin.png').convert_alpha()
]

# player sprites and settings
player = [
    pygame.image.load('images/player/p1.png').convert_alpha(), 
    pygame.image.load('images/player/p2.png').convert_alpha(), 
    pygame.image.load('images/player/pd.png').convert_alpha()
]
player_dir = 0
player_state = 0
player_x = 95
player_y = 45
player_xv = 0
player_yv = 0
player_can_jump = False
player_image = 0
player_rect = None
player_collide = False
player_walk_speed = 2
player_jump_height = 5

# enemy sprites
enemy = [
    pygame.image.load('images/enemy/e1.png').convert_alpha(), 
    pygame.image.load('images/enemy/e2.png').convert_alpha(), 
    pygame.image.load('images/enemy/ed.png').convert_alpha()
]

# ui images
ui = [
    [
        pygame.image.load('images/ui/b1.png').convert_alpha(), 
        pygame.image.load('images/ui/b2.png').convert_alpha(), 
        pygame.image.load('images/ui/b3.png').convert_alpha()
    ], 
    [
        pygame.image.load('images/ui/b1p.png').convert_alpha(), 
        pygame.image.load('images/ui/b2p.png').convert_alpha(), 
        pygame.image.load('images/ui/b3p.png').convert_alpha()
    ], 
    [
        pygame.image.load('images/ui/play.png').convert_alpha(), 
        pygame.image.load('images/ui/play_p.png').convert_alpha()
        
    ], 
    [
        pygame.image.load('images/ui/retry.png').convert_alpha(), 
        pygame.image.load('images/ui/retry_p.png').convert_alpha()
    ], 
    [
        pygame.image.load('images/ui/next.png').convert_alpha(), 
        pygame.image.load('images/ui/next_p.png').convert_alpha()
    ], 
    [
        pygame.image.load('images/ui/menu.png').convert_alpha(), 
        pygame.image.load('images/ui/menu_p.png').convert_alpha()
    ]
]
# ui variables
b1_pos = (35, screen_h - 25)
b2_pos = (10, screen_h - 25)
b3_pos = (screen_w - 30, screen_h - 25)
b1_rect = ui[0][0].get_rect(topleft=b1_pos)
b2_rect = ui[0][1].get_rect(topleft=b2_pos)
b3_rect = ui[0][2].get_rect(topleft=b3_pos)
b1_pressed = False
b2_pressed = False
b3_pressed = False
menu = {
    'logo_text': {
        'text': font.render('Black Cube Platformer +', False, (0, 0, 0)),
        'pos': (19, 10)
    }, 
    'play_button': {
        'sprite': ui[2], 
        'pos': (80, 50), 
        'pressed': False, 
        'old_pressed': False, 
        'rect': ui[2][0].get_rect(topleft=(80, 50))
    }
}
levels = {
    'levels_text': {
        'text': font.render('Levels', False, (0, 0, 0)),
        'pos': (15, 5)
    }, 
    'menu_button': {
        'sprite': ui[5], 
        'pos': (5, 75), 
        'pressed': False, 
        'old_pressed': False, 
        'rect': ui[5][0].get_rect(topleft=(5, 75))
    }, 
    'levels_select': {
    }
}
def set_levels_select():
    text = None
    position = (-15, 25)
    pressed = False
    rect = None
    for i in range(1, levels_count + 1):
        if i < 10:
            text = font.render(' ' + str(i) + ' ', False, (0, 0, 0))
        else:
            text = font.render(str(i), False, (0, 0, 0))
        if i == 6 or i == 11:
            position = (15, position[1] + 15)
        else:
            position = (position[0] + 30, position[1] + 0)
        pressed = False
        rect = text.get_rect(topleft=position)
        levels['levels_select'][i] = {
            'text': text,
            'pos': position, 
            'pressed': pressed, 
            'rect': rect
        }
set_levels_select()


loose_screen = {
    'loose_text': {
        'text': font.render('You dead!', False, (0, 0, 0)),
        'pos': (68, 10)
    }, 
    'retry_button': {
        'sprite': ui[3], 
        'pos': (77.5, 50), 
        'pressed': False, 
        'old_pressed': False, 
        'rect': ui[3][0].get_rect(topleft=(77.5, 50))
    }, 
    'menu_button': {
        'sprite': ui[5], 
        'pos': (80, 75), 
        'pressed': False, 
        'old_pressed': False, 
        'rect': ui[5][0].get_rect(topleft=(80, 75))
    }
}

win_screen = {
    'win_text': {
        'text': font.render('You win!', False, (0, 0, 0)),
        'pos': (72.5, 10)
    }, 
    'next_button': {
        'sprite': ui[4], 
        'pos': (80, 50), 
        'pressed': False, 
        'old_pressed': False, 
        'rect': ui[4][0].get_rect(topleft=(77.5, 50))
    }, 
    'menu_button': {
        'sprite': ui[5], 
        'pos': (80, 75), 
        'pressed': False, 
        'old_pressed': False, 
        'rect': ui[5][0].get_rect(topleft=(80, 75))
    }
}
print(screen_w / 2 - win_screen['win_text']['text'].get_width() / 2)
print(screen_w / 2 - win_screen['menu_button']['sprite'][0].get_width() / 2)

# coins variables
coins = 0
coins_text = font.render('COINS : ' + '0', False, (0, 0, 0))

# game sounds
sounds = [
    pygame.mixer.Sound('sounds/music.mp3'), 
    pygame.mixer.Sound('sounds/click.mp3'), 
    pygame.mixer.Sound('sounds/coin.mp3'), 
    pygame.mixer.Sound('sounds/loose.mp3')
]

# camera variables
cam_x = 0
cam_y = 0

# scenes reset system
def reset_scene(scene_reset):
    if scene_reset == 0:
        reset_scene_0()
    elif scene_reset == 1:
        reset_scene_1()
    elif scene_reset == 2:
        reset_scene_2()
    elif scene_reset == 3:
        reset_scene_3()
    elif scene_reset == 4:
        reset_scene_4()

def reset_scene_2():
    global player_dir, player_state, player_x, player_y, player_xv, player_yv, player_can_jump, player_image, player_rect, player_collide, b1_pos, b2_pos, b3_pos, b1_rect, b2_rect, b3_rect, b1_pressed, b2_pressed, b3_pressed, coins, coins_text, cam_x, cam_y, loaded_level
    player_dir = 0
    player_state = 0
    player_x = 95
    player_y = 45
    player_xv = 0
    player_yv = 0
    player_can_jump = False
    player_image = 0
    player_rect = None
    player_collide = False
    b1_pos = (35, screen_h - 25)
    b2_pos = (10, screen_h - 25)
    b3_pos = (screen_w - 30, screen_h - 25)
    b1_rect = ui[0][0].get_rect(topleft=b1_pos)
    b2_rect = ui[0][1].get_rect(topleft=b2_pos)
    b3_rect = ui[0][2].get_rect(topleft=b3_pos)
    b1_pressed = False
    b2_pressed = False
    b3_pressed = False
    coins = 0
    coins_text = font.render('COINS : ' + str(coins), False, (0, 0, 0))
    cam_x = 0
    cam_y = 0
    try:
        with open('levels/' + level_file_name, 'r') as file_level:
            loaded_level = file_level.read().split('\n')
    except FileNotFoundError:
        loaded_level = []
        
def reset_scene_0():
    global menu
    menu = {
        'logo_text': {
            'text': font.render('Black Cube Platformer +', False, (0, 0, 0)), 
            'pos': (19, 10)
        }, 
        'play_button': {
            'sprite': ui[2], 
            'pos': (80, 50), 
            'pressed': False, 
            'old_pressed': False, 
            'rect': ui[2][0].get_rect(topleft=(80, 50))
        }
    }

def reset_scene_3():
    global loose_screen
    loose_screen = {
        'loose_text': {
            'text': font.render('You dead!', False, (0, 0, 0)),
            'pos': (68, 10)
        }, 
        'retry_button': {
            'sprite': ui[3], 
            'pos': (77.5, 50), 
            'pressed': False, 
            'old_pressed': False, 
            'rect': ui[3][0].get_rect(topleft=(77.5, 50))
        }, 
        'menu_button': {
            'sprite': ui[5], 
            'pos': (80, 75), 
            'pressed': False, 
            'old_pressed': False, 
            'rect': ui[5][0].get_rect(topleft=(80, 75))
        }
    }
def reset_scene_1():
    global levels
    levels = {
        'levels_text': {
            'text': font.render('Levels', False, (0, 0, 0)),
            'pos': (15, 5)
        }, 
        'menu_button': {
            'sprite': ui[5], 
            'pos': (5, 75), 
            'pressed': False, 
            'old_pressed': False, 
            'rect': ui[5][0].get_rect(topleft=(5, 75))
        }, 
        'levels_select': {
        }
    }
    set_levels_select()
def reset_scene_4():
    global win_screen
    win_screen = {
        'win_text': {
            'text': font.render('You win!', False, (0, 0, 0)),
            'pos': (72.5, 10)
        }, 
        'next_button': {
            'sprite': ui[4], 
            'pos': (80, 50), 
            'pressed': False, 
            'old_pressed': False, 
            'rect': ui[4][0].get_rect(topleft=(77.5, 50))
        }, 
        'menu_button': {
            'sprite': ui[5], 
            'pos': (80, 75), 
            'pressed': False, 
            'old_pressed': False, 
            'rect': ui[5][0].get_rect(topleft=(80, 75))
        }
    }

# music loop
sounds[0].play(-1)


# scene variables
scene = 0
scene_transfering = False
scene_transfer = 0
scene_timer = 0
scene_transfer_time = {
    0: 0.125, 
    1: 1
}
def scene_transmission(id, time_id):
    global scene, scene_transfering, scene_transfer, scene_timer, scene_transfer_time
    if scene_transfering and scene_transfer == id:
        if scene_timer == 0:
            scene_timer = time.time()
        elif scene_timer != 0:
            if time.time() - scene_timer >= scene_transfer_time[time_id]:
                scene = id
                scene_transfering = False
                scene_transfer = 0
                scene_timer = 0
                reset_scene(id)

reset_scene(scene)

# main loop
run = True
while run:
    events = pygame.event.get()
    clock.tick(fps)
    if scene == 0:
        screen.fill((255, 255, 255))
        # rendering
        screen.blit(menu['logo_text']['text'], menu['logo_text']['pos'])
        screen.blit(menu['play_button']['sprite'][menu['play_button']['pressed']], menu['play_button']['pos'])
        
        # pressed check +{
        if not scene_transfering:
            menu['play_button']['old_pressed'] = menu['play_button']['pressed']
            menu['play_button']['pressed'] = False
            for finger, pos in fingers.items():
                if menu['play_button']['rect'].collidepoint(pos):
                    menu['play_button']['pressed'] = True
            if menu['play_button']['old_pressed'] and not menu['play_button']['pressed']:
                sounds[1].play()
                scene_transfer = 1
                scene_transfering = True
        # }+
    elif scene == 1:
        screen.fill((255, 255, 255))
        # rendering
        screen.blit(levels['levels_text']['text'], levels['levels_text']['pos'])
        screen.blit(levels['menu_button']['sprite'][levels['menu_button']['pressed']], levels['menu_button']['pos'])
        for id, data in levels['levels_select'].items():
            screen.blit(data['text'], data['pos'])
        # pressed check +{
        if not scene_transfering:
            levels['menu_button']['old_pressed'] = levels['menu_button']['pressed']
            levels['menu_button']['pressed'] = False
            for finger, pos in fingers.items():
                if levels['menu_button']['rect'].collidepoint(pos):
                    levels['menu_button']['pressed'] = True
            if levels['menu_button']['old_pressed'] and not levels['menu_button']['pressed']:
                sounds[1].play()
                scene_transfer = 0
                scene_transfering = True
            for finger, pos in fingers.items():
                for id, data in levels['levels_select'].items():
                    if data['rect'].collidepoint(pos):
                        data['text'] = font.render(str(id) if id > 9 else ' ' + str(id) + ' ', False, (100, 100, 100))
                        scene_transfering = True
                        scene_transfer = 2
                        level_name = str(id)
                        level_file_name = level_name + '.txt'
                        sounds[1].play()
                        break
                if scene_transfering:
                    break
        # }+
    elif scene == 2:
        
        # set coins text
        coins_text = font.render('COINS : ' + str(coins), False, (0, 0, 0))
        
        # buttons pressed check
        b1_pressed = False
        b2_pressed = False
        b3_pressed = False
        for finger, pos in fingers.items():
            if b1_rect.collidepoint(pos):
                b1_pressed = True
            if b2_rect.collidepoint(pos):
                b2_pressed = True
            if b3_rect.collidepoint(pos):
                b3_pressed = True
        
        
        screen.fill((255, 255, 255))
        
        # set camera
        cam_x = player_x - 95
        cam_y = player_y - 45
        
        
        # level render and set hitboxes +{
        level_hitboxes[0].clear()
        level_hitboxes[1].clear()
        level_hitboxes[2].clear()
        level_hitboxes[3].clear()
        element_splited = None
        object_surf = None
        idx = -1
        for element in loaded_level:
            idx += 1
            element_splited = element.split(', ')
            if element_splited[0] == '0':
                if int(element_splited[1]) == 0:
                    screen.blit(blocks[0], (int(element_splited[2]) - cam_x, int(element_splited[3]) - cam_y))
                    level_hitboxes[0].append(blocks[0].get_rect(topleft=(int(element_splited[2]) - cam_x, int(element_splited[3]) - cam_y)))
                elif int(element_splited[1]) == 1:
                    screen.blit(blocks[1], (int(element_splited[2]) - cam_x, int(element_splited[3]) - cam_y))
                    level_hitboxes[1].append(blocks[1].get_rect(topleft=(int(element_splited[2]) - cam_x, int(element_splited[3]) - cam_y)))
                elif int(element_splited[1]) == 2:
                    new_element_splited = element_splited
                    new_element_splited[5] = str(int(new_element_splited[5]) + 1)
                    if int(new_element_splited[5]) >= 30:
                        new_element_splited[5] = str(0)
                        new_element_splited[4] = str(1 -  int(new_element_splited[4]))
                    joined_new_element_splited = None
                    for idx1, el in enumerate(new_element_splited):
                        if idx1 == 0:
                            joined_new_element_splited = el + ', '
                        elif idx1 != 0 and idx1 - 1 < len(new_element_splited):
                            joined_new_element_splited += el + ', '
                        elif idx1 - 1 >= len(new_element_splited):
                            joined_new_element_splited += el
                            
                    loaded_level[idx] = joined_new_element_splited
                    screen.blit(blocks[int(new_element_splited[4])], (int(element_splited[2]) - cam_x, int(element_splited[3]) - cam_y))
                    level_hitboxes[int(new_element_splited[4])].append(blocks[1].get_rect(topleft=(int(element_splited[2]) - cam_x, int(element_splited[3]) - cam_y)))
                elif int(element_splited[1]) == 3:
                    new_element_splited = element_splited
                    new_element_splited[5] = str(int(new_element_splited[5]) + 1)
                    if int(new_element_splited[5]) >= 30:
                        new_element_splited[5] = str(0)
                        new_element_splited[4] = str(1 -  int(new_element_splited[4]))
                    joined_new_element_splited = None
                    for idx1, el in enumerate(new_element_splited):
                        if idx1 == 0:
                            joined_new_element_splited = el + ', '
                        elif idx1 != 0 and idx1 - 1 < len(new_element_splited):
                            joined_new_element_splited += el + ', '
                        elif idx1 - 1 >= len(new_element_splited):
                            joined_new_element_splited += el
                            
                    loaded_level[idx] = joined_new_element_splited
                    if int(new_element_splited[4]) == 1:
                        screen.blit(blocks[1], (int(element_splited[2]) - cam_x, int(element_splited[3]) - cam_y))
                        level_hitboxes[1].append(blocks[1].get_rect(topleft=(int(element_splited[2]) - cam_x, int(element_splited[3]) - cam_y)))
                elif int(element_splited[1]) == 4:
                    new_element_splited = element_splited
                    new_element_splited[5] = str(int(new_element_splited[5]) + 1)
                    if int(new_element_splited[5]) >= 30:
                        new_element_splited[5] = str(0)
                        new_element_splited[4] = str(1 -  int(new_element_splited[4]))
                    joined_new_element_splited = None
                    for idx1, el in enumerate(new_element_splited):
                        if idx1 == 0:
                            joined_new_element_splited = el + ', '
                        elif idx1 != 0 and idx1 - 1 < len(new_element_splited):
                            joined_new_element_splited += el + ', '
                        elif idx1 - 1 >= len(new_element_splited):
                            joined_new_element_splited += el
                            
                    loaded_level[idx] = joined_new_element_splited
                    if int(new_element_splited[4]) == 1:
                        screen.blit(blocks[0], (int(element_splited[2]) - cam_x, int(element_splited[3]) - cam_y))
                        level_hitboxes[0].append(blocks[0].get_rect(topleft=(int(element_splited[2]) - cam_x, int(element_splited[3]) - cam_y)))
                    
                elif int(element_splited[1]) == 5:
                    screen.blit(blocks[3], (int(element_splited[2]) - cam_x, int(element_splited[3]) - cam_y))
                    level_hitboxes[1].append(blocks[3].get_rect(topleft=(int(element_splited[2]) - cam_x, int(element_splited[3]) - cam_y)))
                    
                    new_element_splited = element_splited
                    if int(new_element_splited[4]) == 0:
                        if int(new_element_splited[7]) == 0:
                            if int(new_element_splited[2]) != int(new_element_splited[6]):
                                new_element_splited[2] = str(int(new_element_splited[2]) + 1)
                            else:
                                new_element_splited[7] = '1'
                        elif int(new_element_splited[7]) == 1:
                            if int(new_element_splited[2]) != int(new_element_splited[5]):
                                new_element_splited[2] = str(int(new_element_splited[2]) - 1)
                            else:
                                new_element_splited[7] = '0'
                    elif int(new_element_splited[4]) == 1:
                        
                        
                        if int(new_element_splited[7]) == 0:
                            if int(new_element_splited[3]) != int(new_element_splited[6]):
                                new_element_splited[3] = str(int(new_element_splited[3]) - 1)
                            else:
                                new_element_splited[7] = '1'
                        elif int(new_element_splited[7]) == 1:
                            if int(new_element_splited[3]) != int(new_element_splited[5]):
                                new_element_splited[3] = str(int(new_element_splited[3]) + 1)
                            else:
                                new_element_splited[7] = '0'
                    
                    joined_new_element_splited = None
                    for idx1, el in enumerate(new_element_splited):
                        if idx1 == 0:
                            joined_new_element_splited = el + ', '
                        elif idx1 != 0 and idx1 - 1 < len(new_element_splited):
                            joined_new_element_splited += el + ', '
                        elif idx1 - 1 >= len(new_element_splited):
                            joined_new_element_splited += el
                            
                    loaded_level[idx] = joined_new_element_splited
                elif int(element_splited[1]) == 6:
                    screen.blit(items[0], (int(element_splited[2]) + 4 - cam_x, int(element_splited[3]) + 4 - cam_y))
                    level_hitboxes[2].append([items[0].get_rect(topleft=(int(element_splited[2]) + 4 - cam_x, int(element_splited[3]) + 4 - cam_y)), idx, int(element_splited[1])])
                elif int(element_splited[1]) == 7:
                    screen.blit(items[2], (int(element_splited[2]) + 4 - cam_x, int(element_splited[3]) + 4 - cam_y))
                    level_hitboxes[2].append([items[2].get_rect(topleft=(int(element_splited[2]) + 4 - cam_x, int(element_splited[3]) + 4 - cam_y)), idx, int(element_splited[1])])
                elif int(element_splited[1]) == 8:
                    screen.blit(items[1], (int(element_splited[2]) + 4 - cam_x, int(element_splited[3]) - cam_y))
                    level_hitboxes[2].append([items[1].get_rect(topleft=(int(element_splited[2]) + 4 - cam_x, int(element_splited[3]) - cam_y)), idx, int(element_splited[1])])
                elif int(element_splited[1]) == 9:
                    object_surf = font.render(element_splited[4], False, (0, 0, 0))
                    screen.blit(object_surf, (int(element_splited[2]) - object_surf.get_width() / 2 - cam_x, int(element_splited[3]) - cam_y))
            elif element_splited[0] == '1':
                pass
        # }+
        
        # setting player image
        if player_state == 0:
            if player_dir == 0:
                player_image = 0
            elif player_dir == 1:
                player_image = 1
        elif player_state == 2:
            player_image = 2
        
        # player render
        screen.blit(player[player_image], (player_x - cam_x, player_y - cam_y))
        
        # controling player with buttons
        if b1_pressed and not b2_pressed:
            player_xv = -player_walk_speed
            player_dir = 0
        elif b2_pressed and not b1_pressed:
            player_xv = player_walk_speed
            player_dir = 1
        if b3_pressed and player_can_jump:
            player_yv = player_jump_height
            
        # player physics ${
        if player_state == 0:
            player_y -= player_yv
            player_y = round(player_y)
            player_rect = player[0].get_rect(topleft=(player_x - cam_x, player_y - cam_y))
            player_collide = False
            for hitbox in level_hitboxes[0]:
                if player_rect.colliderect(hitbox):
                    player_collide = True
            for hitbox in level_hitboxes[1]:
                if player_rect.colliderect(hitbox):
                    player_collide = True
                    player_state = 2
                    scene_transfer = 3
                    sounds[3].play()
                    
            if not player_collide:
                player_yv = max(-10, player_yv - 0.5)
                player_can_jump = False
            else:
                while player_collide:
                    player_y += -0.5 if player_yv < 0 else 0.5
                    player_rect = player[0].get_rect(topleft=(player_x - cam_x, player_y - cam_y))
                    player_collide = False
                    for hitbox in level_hitboxes[0]:
                        if player_rect.colliderect(hitbox):
                            player_collide = True
                    for hitbox in level_hitboxes[1]:
                        if player_rect.colliderect(hitbox):
                            player_collide = True
                            player_state = 2
                            scene_transfer = 3
                            sounds[3].play()
                            
                if player_yv < 0:
                    player_yv = 0
                    player_can_jump = True
                elif player_yv >= 0:
                    player_yv = -0.5
                    player_can_jump = False
                
            player_x -= player_xv
            player_x = round(player_x)
            player_rect = player[0].get_rect(topleft=(player_x - cam_x, player_y - cam_y))
            player_collide = False
            for hitbox in level_hitboxes[0]:
                if player_rect.colliderect(hitbox):
                    player_collide = True
            for hitbox in level_hitboxes[1]:
                if player_rect.colliderect(hitbox):
                    player_collide = True
                    player_state = 2
                    scene_transfer = 3
                    sounds[3].play()
                    
            if not player_collide:
                player_xv *= 0.5
            else:
                player_x += player_xv / 2
                
                for i in range(1):
                    player_rect = player[0].get_rect(topleft=(player_x - cam_x, player_y - cam_y))
                    player_collide = False
                    for hitbox in level_hitboxes[0]:
                        if player_rect.colliderect(hitbox):
                            player_collide = True
                    for hitbox in level_hitboxes[1]:
                        if player_rect.colliderect(hitbox):
                            player_collide = True
                            player_state = 2
                            scene_transfer = 3
                            sounds[3].play()
                            
                    if not player_collide:
                        pass
                    else:
                        player_x += player_xv / 2
                        
                player_xv = 0
            
            if player_y >= 300:
                player_state = 2
                scene_transfer = 3
                sounds[3].play()
            
            player_rect = player[0].get_rect(topleft=(player_x - cam_x, player_y - cam_y))
            for item in level_hitboxes[2]:
                if player_rect.colliderect(item[0]):
                    if item[2] == 6:
                        loaded_level.pop(item[1])
                        coins += 1
                        sounds[2].play()
                        break
                    elif item[2] == 7:
                        loaded_level.pop(item[1])
                        if coins - 1 >= 0:
                            coins -= 1
                            sounds[2].play()
                        else:
                            player_state = 2
                            scene_transfer = 3
                            sounds[3].play()
                        break
                    elif item[2] == 8:
                        player_state = 1
                        scene_transfer = 4
                        break
        # }$
            
        # rendering buttons
        screen.blit(ui[b1_pressed][0], b1_pos)
        screen.blit(ui[b2_pressed][1], b2_pos)
        screen.blit(ui[b3_pressed][2], b3_pos)
        
        
        screen.blit(coins_text, (screen_w - 5 - coins_text.get_width(), 5))
        
        # scene transfering ×{
        if player_state == 2 and not scene_transfering:
            scene_transfering = True
            scene_transfer = 3
        elif player_state == 1 and not scene_transfering:
            scene_transfering = True
            scene_transfer = 4
        
        
        # }×
        
    elif scene == 3:
        screen.fill((255, 255, 255))
        # rendering
        screen.blit(loose_screen['loose_text']['text'], loose_screen['loose_text']['pos'])
        screen.blit(loose_screen['retry_button']['sprite'][loose_screen['retry_button']['pressed']], loose_screen['retry_button']['pos'])
        screen.blit(loose_screen['menu_button']['sprite'][loose_screen['menu_button']['pressed']], loose_screen['menu_button']['pos'])
        
        # pressed check +{
        if not scene_transfering:
            loose_screen['retry_button']['old_pressed'] = loose_screen['retry_button']['pressed']
            loose_screen['retry_button']['pressed'] = False
            for finger, pos in fingers.items():
                if loose_screen['retry_button']['rect'].collidepoint(pos):
                    loose_screen['retry_button']['pressed'] = True
            if loose_screen['retry_button']['old_pressed'] and not loose_screen['retry_button']['pressed']:
                sounds[1].play()
                scene_transfer = 2
                scene_transfering = True
            loose_screen['menu_button']['old_pressed'] = loose_screen['menu_button']['pressed']
            loose_screen['menu_button']['pressed'] = False
            for finger, pos in fingers.items():
                if loose_screen['menu_button']['rect'].collidepoint(pos):
                    loose_screen['menu_button']['pressed'] = True
            if loose_screen['menu_button']['old_pressed'] and not loose_screen['menu_button']['pressed']:
                sounds[1].play()
                scene_transfer = 0
                scene_transfering = True
        # }+
    elif scene == 4:
        screen.fill((255, 255, 255))
        # rendering
        screen.blit(win_screen['win_text']['text'], win_screen['win_text']['pos'])
        screen.blit(win_screen['next_button']['sprite'][win_screen['next_button']['pressed']], win_screen['next_button']['pos'])
        screen.blit(win_screen['menu_button']['sprite'][win_screen['menu_button']['pressed']], win_screen['menu_button']['pos'])
        
        # pressed check +{
        if not scene_transfering:
            win_screen['next_button']['old_pressed'] = win_screen['next_button']['pressed']
            win_screen['next_button']['pressed'] = False
            for finger, pos in fingers.items():
                if win_screen['next_button']['rect'].collidepoint(pos):
                    win_screen['next_button']['pressed'] = True
            if win_screen['next_button']['old_pressed'] and not win_screen['next_button']['pressed']:
                sounds[1].play()
                if int(level_name) < levels_count:
                    level_name = str(int(level_name) + 1)
                    level_file_name = level_name + '.txt'
                    scene_transfer = 2
                else:
                    scene_transfer = 1
                scene_transfering = True
            win_screen['menu_button']['old_pressed'] = win_screen['menu_button']['pressed']
            win_screen['menu_button']['pressed'] = False
            for finger, pos in fingers.items():
                if win_screen['menu_button']['rect'].collidepoint(pos):
                    win_screen['menu_button']['pressed'] = True
            if win_screen['menu_button']['old_pressed'] and not win_screen['menu_button']['pressed']:
                sounds[1].play()
                scene_transfer = 0
                scene_transfering = True
        # }+
        
    # scene transmissions
    scene_transmission(0, 0)
    scene_transmission(1, 0)
    scene_transmission(2, 0)
    scene_transmission(3, 1)
    scene_transmission(4, 1)
    
    
    # after scene frame code @{
    pygame.display.update()
    
    for event in events:
        if event.type == pygame.QUIT:
            pygame.quit()
            run = False
            break
        if event.type == pygame.FINGERDOWN:
            fingers[event.finger_id] = (event.x * screen_w, event.y * screen_h)
        if event.type == pygame.FINGERUP:
            fingers.pop(event.finger_id, None)
    # }@